from django.apps import AppConfig


class JumbleConfig(AppConfig):
    name = 'jumble'
