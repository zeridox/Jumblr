$(document).ready(function(){
    $('.match1').hover(function(){
        // $(this).next().toggle();
        console.log('clicked match1');

        if(0=0){
            console.log('hey');
        };
    });
});